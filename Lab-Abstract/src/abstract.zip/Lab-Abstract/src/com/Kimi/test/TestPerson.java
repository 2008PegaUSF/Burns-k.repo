package com.Kimi.test;

import com.Kimi.Person;

public class TestPerson {
	
	public static void main(String[] args) {
		Person adam = new Person();
	}
	

}
